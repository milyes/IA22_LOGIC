# ETAPE 3 - Prompt Firewall - Z-CORE ENTERPRISE v22.0.0
## NetSecurePro IA - Zoubirou Mohammed Ilyes | ORCID 0009-0007-7571-3178

**Etape 3/10 - ETAPE 3 - Prompt Firewall**

Description: Rules + Structure + Entropy. Detection hijack, system prompt extraction, encoded content, role conflict, jailbreak. PROMPT->Rules/Structure/Entropy->Risk->ALLOW/REVIEW/BLOCK. Recall 66.7% axe amelioration.

Date: 2026-10-15
Version: 22.0.0 Etape 3
Repo: https://github.com/milyes/IA22_LOGIC.git
Live: https://milyes.github.io/IA22_LOGIC/

Contenu jusqu'a etape 3 inclus.

Prochaines etapes: 4 -> Voir ETAPES_1_A_19_COMPLET.md
