#!/bin/bash
set -e
cd "/mnt/data/IA22_LOGIC"
echo "=== Push to milyes/IA22_LOGIC ==="
git add .
git commit -m "FINAL v22.0.0 - Z-CORE ENTERPRISE - NetSecurePro IA - 2026-10-13" || true
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/milyes/IA22_LOGIC.git
git push -u origin main --force
echo "Done! Enable Pages at https://github.com/milyes/IA22_LOGIC/settings/pages -> /docs"
