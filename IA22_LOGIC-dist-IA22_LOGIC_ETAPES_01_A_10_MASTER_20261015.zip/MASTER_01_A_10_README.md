# IA22_LOGIC - ETAPES 1 A 10 - MASTER
Date: 2026-10-15T06:40:22.765693
10 ZIPs separes + projet complet
https://github.com/milyes/IA22_LOGIC.git
