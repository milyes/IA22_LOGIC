# IA22_LOGIC - Hexade Complete
Creator: Mohammed Ilyes Zoubirou
Montreal 2023-2026
